<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/26
 * Time: 13:40
 */
namespace app\admin\controller;
class Index
{
    public function index(){
        return "这简直就是受罪啊，WLPL后台见过没有？？？就是这个";
    }
}