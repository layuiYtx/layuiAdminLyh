<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

// [ 应用入口文件 ]
//应用入口选择文件，根据前缀选择不同的应用
$url = $_SERVER['HTTP_HOST'];
$arrU = explode('.',$url);
if(is_https()){
    define('HTTP_HOST','http://'.$url);  //全局变量，当前域名
}else{
    define('HTTP_HOST','https://'.$url);  //全局变量，当前域名
}
define('HTTP_F',$arrU[0]); //全局变量，二级域名的前戳

$config = require_once "config.php";

if(isset($config[$arrU[0]])){
    require_once "public/".$config[$arrU[0]] . '.php';
}else{
    //站点未开放
    echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <title>Title</title>
    <link href=\"/public/static/venter/layui/css/layui.css\"  rel=\"stylesheet\" />

    <script src=\"/public/static/js/jquery-3.3.1.min.js\" ></script>
    <script src=\"/public/static/venter/layui/layui.all.js\" ></script>
</head>
<body>
<div id=\"content\" style=\"padding: 50px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;\">
    <h1 style=\"margin: 10px;text-align: center;margin-bottom: 30px;\">该站点暂未开放</h1>
    <p style=\"text-indent: 2rem;margin-bottom: 50px;\">这个站点暂未开放，请联系网站管理员，去配置好网站</p>
    <p id=\"time\" style=\"float: right;\" >当前时间是：</p>
</div>
</body>
<script>
    var layer = layui.layer;
    layer.open({
        type: 1
        ,title: false //不显示标题栏
        ,closeBtn: false
        ,area: '400px;'
        ,shade: 0.8
        ,id: 'LAY_layuipro' //设定一个id，防止重复弹出
        ,resize: false
        ,btnAlign: 'c'
        ,moveType: 1 //拖拽模式，0或者1
        ,content:$('#content')
    });
    getLangDate();
    //值小于10时，在前面补0
    function dateFilter(date){
        if(date < 10){return \"0\"+date;}
        return date;
    }
    function getLangDate(){
        var dateObj = new Date(); //表示当前系统时间的Date对象
        var year = dateObj.getFullYear(); //当前系统时间的完整年份值
        var month = dateObj.getMonth()+1; //当前系统时间的月份值
        var date = dateObj.getDate(); //当前系统时间的月份中的日
        var day = dateObj.getDay(); //当前系统时间中的星期值
        var weeks = [\"星期日\",\"星期一\",\"星期二\",\"星期三\",\"星期四\",\"星期五\",\"星期六\"];
        var week = weeks[day]; //根据星期值，从数组中获取对应的星期字符串
        var hour = dateObj.getHours(); //当前系统时间的小时值
        var minute = dateObj.getMinutes(); //当前系统时间的分钟值
        var second = dateObj.getSeconds(); //当前系统时间的秒钟值
        var timeValue = \"\" +((hour >= 12) ? (hour >= 18) ? \"晚上\" : \"下午\" : \"上午\" ); //当前时间属于上午、晚上还是下午
        newDate = dateFilter(year)+\"年\"+dateFilter(month)+\"月\"+dateFilter(date)+\"日 \"+\" \"+dateFilter(hour)+\":\"+dateFilter(minute)+\":\"+dateFilter(second);
        document.getElementById(\"time\").innerHTML = newDate+\"　\"+week;
        setTimeout(\"getLangDate()\",1000);
    }
</script>
</html>";
    die();
}


function is_https() {
    if ( !empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') {
        return true;
    } elseif ( isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https' ) {
        return true;
    } elseif ( !empty($_SERVER['HTTP_FRONT_END_HTTPS']) && strtolower($_SERVER['HTTP_FRONT_END_HTTPS']) !== 'off') {
        return true;
    }
    return false;
}
