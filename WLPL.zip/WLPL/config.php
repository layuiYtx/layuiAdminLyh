<?php

return [
    'www'   =>  'index',
    'admin' =>  'admin'
];